1. Upload the index.php file in your server. eq in folder perfex_crm_test

2. Go to yourdomain.com/perfex_crm_test/index.php
